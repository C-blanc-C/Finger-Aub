from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import cv2
import numpy as np
from ultralytics import YOLO
import sys

class FingerWidget(QWidget):
    """Widget to show a finger's actuation percentage"""
    def __init__(self, name, parent=None):
        super().__init__(parent)
        self.name = name
        self.percentage = 0
        self.setMinimumSize(100, 200)
        
    def setPercentage(self, value):
        self.percentage = max(0, min(100, value))
        self.update()
        
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Draw finger bar
        rect = self.rect().adjusted(10, 10, -10, -30)
        painter.setPen(QPen(Qt.black, 2))
        painter.setBrush(Qt.white)
        painter.drawRect(rect)
        
        # Draw fill level
        fill_height = rect.height() * (self.percentage / 100)
        fill_rect = QRect(rect.x(), rect.bottom() - fill_height, rect.width(), fill_height)
        painter.setBrush(QColor(0, 255, 0))
        painter.drawRect(fill_rect)
        
        # Draw percentage text
        painter.drawText(rect.x(), rect.bottom() + 20, rect.width(), 30,
                        Qt.AlignCenter, f"{self.name}\n{self.percentage:.0f}%")

class HandGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Robotic Hand Control")
        self.setMinimumSize(1200, 600)
        
        # Main widget and layout
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QHBoxLayout(main_widget)
        
        # Camera view
        self.camera_label = QLabel()
        self.camera_label.setMinimumSize(640, 480)
        layout.addWidget(self.camera_label)
        
        # Fingers display
        fingers_widget = QWidget()
        fingers_layout = QHBoxLayout(fingers_widget)
        self.fingers = {}
        for name in ['Thumb', 'Index', 'Middle', 'Ring', 'Pinky']:
            finger = FingerWidget(name)
            self.fingers[name.lower()] = finger
            fingers_layout.addWidget(finger)
        layout.addWidget(fingers_widget)
        
        # Initialize camera and YOLO
        self.init_camera()
        self.yolo = YOLO('yolov8m.pt')
        
        # Start timer for camera updates
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_camera)
        self.timer.start(30)  # Update every 30ms
        
    def init_camera(self):
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            QMessageBox.critical(self, "Error", "Could not open camera!")
            self.close()
            
    def calculate_finger_positions(self, object_class, box_width, box_height):
        """Calculate finger positions based on detected object"""
        # Default grasp patterns for different object types
        grasp_patterns = {
            'bottle': {'thumb': 80, 'index': 70, 'middle': 70, 'ring': 60, 'pinky': 50},
            'cup': {'thumb': 90, 'index': 80, 'middle': 80, 'ring': 80, 'pinky': 70},
            'cell phone': {'thumb': 60, 'index': 50, 'middle': 50, 'ring': 50, 'pinky': 40},
            'book': {'thumb': 90, 'index': 30, 'middle': 30, 'ring': 30, 'pinky': 30},
            'mouse': {'thumb': 40, 'index': 30, 'middle': 30, 'ring': 20, 'pinky': 20},
            # Add more objects and their grasp patterns
        }
        
        # Get default pattern or create one based on object size
        if object_class.lower() in grasp_patterns:
            return grasp_patterns[object_class.lower()]
        else:
            # Generic grasp based on object size
            aspect_ratio = box_width / box_height
            size_factor = min((box_width * box_height) / (640 * 480), 1.0)
            
            if aspect_ratio > 1.5:  # Wide object
                return {
                    'thumb': 90 * size_factor,
                    'index': 70 * size_factor,
                    'middle': 70 * size_factor,
                    'ring': 70 * size_factor,
                    'pinky': 60 * size_factor
                }
            elif aspect_ratio < 0.67:  # Tall object
                return {
                    'thumb': 80 * size_factor,
                    'index': 90 * size_factor,
                    'middle': 90 * size_factor,
                    'ring': 80 * size_factor,
                    'pinky': 70 * size_factor
                }
            else:  # Regular object
                base_closure = 70 * size_factor
                return {
                    'thumb': base_closure + 10,
                    'index': base_closure,
                    'middle': base_closure,
                    'ring': base_closure - 10,
                    'pinky': base_closure - 20
                }
    
    def update_camera(self):
        ret, frame = self.cap.read()
        if not ret:
            return
            
        # Run YOLO detection
        results = self.yolo(frame, conf=0.3)
        
        # Get the largest detected object
        largest_box = None
        largest_area = 0
        largest_class = None
        
        for r in results:
            boxes = r.boxes
            for box in boxes:
                x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                area = (x2 - x1) * (y2 - y1)
                if area > largest_area:
                    largest_area = area
                    largest_box = (int(x1), int(y1), int(x2), int(y2))
                    largest_class = r.names[int(box.cls[0])]
        
        # Draw detection and update finger positions
        if largest_box is not None:
            x1, y1, x2, y2 = largest_box
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, largest_class, (x1, y1-10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
            
            # Calculate and update finger positions
            box_width = x2 - x1
            box_height = y2 - y1
            finger_positions = self.calculate_finger_positions(largest_class, box_width, box_height)
            
            for finger, percentage in finger_positions.items():
                self.fingers[finger].setPercentage(percentage)
        
        # Convert frame to Qt format and display
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_frame.shape
        qt_img = QImage(rgb_frame.data, w, h, w * ch, QImage.Format_RGB888)
        self.camera_label.setPixmap(QPixmap.fromImage(qt_img))
    
    def closeEvent(self, event):
        self.cap.release()
        event.accept()

def main():
    app = QApplication(sys.argv)
    window = HandGUI()
    window.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
